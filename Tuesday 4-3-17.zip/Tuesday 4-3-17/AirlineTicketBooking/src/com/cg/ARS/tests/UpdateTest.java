package com.cg.ARS.tests;

import static org.junit.Assert.*;

import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.ARS.daos.BookingDao;
import com.cg.ARS.daos.BookingDaoImpl;

public class UpdateTest {
	BookingDao dao;
	private static final Logger mylogger=
			Logger.getLogger(UpdateTest.class);
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		dao= new BookingDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	
	}

	@Test
	public void test() {
		assertTrue(dao.updateFlightInfo(info));
	}

}
