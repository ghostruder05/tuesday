package com.cg.ARS.servlets;

import java.io.IOException;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.ARS.dto.BookingInformation;
import com.cg.ARS.dto.FlightInfo;
import com.cg.ARS.dto.UserClass;
import com.cg.ARS.exceptions.BookingExceptions;
import com.cg.ARS.services.BookingServices;
import com.cg.ARS.services.BookingServicesImpl;


@WebServlet("*.do")
public class AController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookingServices services;
	 private ServletContext ctx;
	
	public AController() throws BookingExceptions {
		services = new BookingServicesImpl();
	}
	
	public void init() throws ServletException {
		
		ctx=super.getServletContext();
		services=(BookingServices)ctx.getAttribute("services");
		try {
			services=new BookingServicesImpl();
		} catch (BookingExceptions e) {
			
			e.printStackTrace();
		} 
	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
		
	}
	
	private void processRequest(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException{
		String cmd = request.getServletPath();
		log("xxx");
		System.out.println(cmd);
		String nextJsp = null;
		RequestDispatcher dispatcher = null;
		ctx.log("Path:"+cmd);
		switch (cmd) {
		
		case "/home.do":
			nextJsp="home.jsp";
			break;
		
			
		case "/login.do":
				nextJsp="login.jsp";
				break;
			
		case "/successLogin.do":
			String userName = request.getParameter("userNm");
			String password = request.getParameter("password");
			try {
				boolean result=services.validateAdmin(userName);
				HttpSession session=request.getSession(true);
				System.out.println("session id:"+session.getId());
				session.setAttribute("user", userName);
				ctx.log("Valid user session started with id"+session.getId());
				nextJsp="adminHome.jsp";

			/*	if(result)
				{
					if(userName=="admin"){
						nextJsp="adminHome.jsp";
					}else if(userName.equalsIgnoreCase("airline-exec")){
						nextJsp="airLineExecutive.jsp";
					}else{
						nextJsp="userFunctions.jsp";
					}
				}*/
				
			} catch (BookingExceptions e) {
				System.out.println("Wrong Credentials");
			}
			
			
			break;
			
		case "/adminUpdate.do":
			nextJsp="adminUpdate.jsp";
			break;
			
		case "/flightInfo.do":
			List<FlightInfo> fList = null;
			try {
				fList = services.showAll();
			} catch (BookingExceptions e) {
				System.out.println("Data not found.");
			}
			request.setAttribute("fList", fList);
			nextJsp="flightInfo.jsp";
			break;
			
		case "/addFlight.do":
			nextJsp="addFlight.jsp";
	
			break;
		
		case "/successInsert.do":
		FlightInfo info = new FlightInfo();
			info.setFlightno(request.getParameter("flightNo"));
			info.setAirlinename(request.getParameter("airLine"));
			info.setDept_city(request.getParameter("src"));
			info.setArr_city(request.getParameter("dest"));
			
			try {
				String d=request.getParameter("dDate").toString();
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date = sdf1.parse(d);
				java.sql.Date sqldeptDate = new Date(date.getTime());
				System.out.println(sqldeptDate);
				info.setDep_date(sqldeptDate);
				
				String a=request.getParameter("aDate").toString();
				SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date1 = sdf2.parse(d);
				java.sql.Date sqlarrDate = new Date(date.getTime());
				System.out.println(sqlarrDate);
				info.setArr_date(sqlarrDate);
			} catch (ParseException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			info.setDep_time(request.getParameter("dTime"));
			info.setArr_time(request.getParameter("aTime"));
			
			String fseat=request.getParameter("fSeats");
			info.setFirstseats(Integer.parseInt(fseat));
			
			String fSeatFare=request.getParameter("fSeatsFare");
			info.setFirstseatfare(Integer.parseInt(fSeatFare));
			
			String bseat=request.getParameter("bSeats");
			info.setBussseats(Integer.parseInt(bseat));
			
			String bSeatfare=request.getParameter("bSeatsFare");
			info.setBussseatfare(Integer.parseInt(bSeatfare));
			
			try {
				services.insertFlightDetails(info);
				nextJsp = "successInsert.jsp";
			} catch (BookingExceptions e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
			
		case "/updateFlightDetails.do":
			String idjsp = request.getParameter("id");
			String id=idjsp.substring(3);
			request.setAttribute("flightNo", id);
			String airLine = request.getParameter("name");
			request.setAttribute("airline", airLine);
			System.out.println(id);
			nextJsp = "updateFlightDetails.jsp";
			break;
			
			
		case "/deleteFlights.do":
			String no1 = request.getParameter("id");
			System.out.println(no1);
			
			try {
				
				boolean status=	services.deleteFlight(no1);
				System.out.println(status);
				if(status==true){
				nextJsp = "successDelete.jsp";
				}
			} catch (BookingExceptions e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
			break;
			
		case "/srsDes.do":
			nextJsp="searchBySrcDes.jsp";
			break;
			
		case "/seacrchFlight.do":
			String src= request.getParameter("source");
			String dest=request.getParameter("destination");
			List<FlightInfo> searchList=null;
			try {
				searchList = services.searchBySrcDest(src,dest);					
			} catch (BookingExceptions e1) {
				
				e1.printStackTrace();
			}
			request.setAttribute("sList", searchList);
			nextJsp="successSearch.jsp";
			break;
			
		case "/bookFlight.do":
			
			break;
			
		case "/executive.do":
			
			nextJsp = "executive.jsp";
			break;
		
		case "/register.do":
			System.out.println("resister....do");
			String uName=request.getParameter("uName");
			String pass=request.getParameter("password");
			String role=request.getParameter("role");
			String mobile=request.getParameter("phone");
			UserClass users=new UserClass();
			users.setUsername(uName);
			users.setPassword(pass);
			users.setRole(role);
			users.setMobile_no(mobile);
			try {
				boolean insert=services.insertUser(users);
				System.out.println(insert);
				if(insert==true){
				nextJsp="successInsert.jsp";
				}
			} catch (BookingExceptions e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("Error in insert"+e);
			}
			break;
			
		case "/user.do":
			nextJsp = "userFunctions.jsp";
			break;
			
		case "/getAllFlightDetails.do":
			
			 try {
				
				List<FlightInfo> flightList = services.showAll();
				System.out.println(flightList);
				request.setAttribute("flist",flightList);
				nextJsp="flightDetails.jsp";
				
				
			} catch (BookingExceptions e) {
				
				e.printStackTrace();
			}
			 break;
		
		case "/searchByDate.do":
		{
			List<FlightInfo> infoList;
			try {
				String d=request.getParameter("dateSearch").toString();
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date date = sdf1.parse(d);
				java.sql.Date sqldeptDate = new Date(date.getTime());	
				infoList =  services.showFlightByDate(sqldeptDate);	
				request.setAttribute("fList", infoList);
				System.out.println("In controller of searchByDate"+infoList);
			} catch (ParseException | BookingExceptions e1) {
				System.out.println(e1);
			}	
			
			nextJsp="searchFlights.jsp";
			break;
			
		}	
		
			 
		case "/bookFlightDetails.do":
			String flightId=request.getParameter("id");
			String flightSrc=request.getParameter("src");
			String flightDest=request.getParameter("dest");
			request.setAttribute("flightCode", flightId);
			request.setAttribute("flightSrc", flightSrc);
			request.setAttribute("flightDest", flightDest);
			nextJsp="book.jsp";
			break;
		
		case "/booked.do":
			{log("xxx");
				try {
				BookingInformation book = new BookingInformation();
				String no=request.getParameter("flightNo");
				book.setFlightno(no);
				String source=request.getParameter("src");
				book.setSrc_city(source);
				String des=request.getParameter("dest");
				book.setDest_city(des);
				String mailId=request.getParameter("mail");
				String noOfPassenger=request.getParameter("noOfPassenger");
				int passengerNo=Integer.parseInt(noOfPassenger);
				String classType=request.getParameter("type");
				String cardNo=request.getParameter("creditCardNo");
				book.setCust_email(mailId);
				book.setNo_of_passenger(passengerNo);
				book.setClass_type(classType);
				book.setCreditcard_info(cardNo);
				log("xxx");
				boolean booked=services.addBookingDetails(book);
				request.setAttribute("bookedticket", booked);
				nextJsp="successBooking.jsp";
			} catch (BookingExceptions e) {
				
				e.printStackTrace();
			}
			
			
			break;	
			}
		default:
			break;
		}
			
		dispatcher = request.getRequestDispatcher(nextJsp);
		dispatcher.forward(request, response);
	}

}
